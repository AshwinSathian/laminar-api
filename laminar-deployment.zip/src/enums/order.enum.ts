export enum OrderStatus {
  placed = 'PLACED',
  dispatched = 'DISPATCHED',
  delivered = 'DELIVERED',
}
