export * from './inventory.module';
