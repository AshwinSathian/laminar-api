export * from './bill-of-materials.module';
