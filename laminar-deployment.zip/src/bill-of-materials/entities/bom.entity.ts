export class Bom {}
