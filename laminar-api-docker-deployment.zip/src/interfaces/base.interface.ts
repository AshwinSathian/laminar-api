import { Meta } from './common.interface';

export interface Base {
  id: string;
  meta: Meta;
}
