export class Inventory {}
